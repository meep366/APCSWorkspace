/**
 * 
 */
package boxBug;

import info.gridworld.actor.Flower;

/**
 * @author jack
 *
 */
public class Clover extends Flower{

	/**
	 * @param args
	 */
	
	
	public void pollinate()
	{
		
	}
	
	public boolean hasBeenPollinated()
	{
		return false;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
