package apTerm1ExamFiles;

public class Tester {

	private static int[] array = new int[5]
	array[0]=1;
	array[1]=2;
	array[2]=3;
    array[3]=4;
    array[4]=5;
	
	
	
	public static void main(String[] args)
	{
		Tester bob = new Tester();
		System.out.println(bob.ReverseArray(array));
		
		
		
		
	}
	
	
}
